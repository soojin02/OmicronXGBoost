# XGBoost Model
library(xgboost)
# Use cross validation
param <- list(objective = "reg:linear", eval_metric = "rmse", alpha = 1, lambda = 0.1)
# XGBoost model
xgb <- xgboost(data = train, label = train_y, params = param, nrounds = 1000, verbose = 0, early_stopping_rounds = 50)
# predictions on test using train
pred_xgb <- predict(xgb, newdata = test)

# submit file
test$ic50_Omicron <- pred_xgb
submit <- data.table(sample_id)
submit$ic50_Omicron <- test$ic50_Omicron
# write csv
fwrite(submit, "./project/volume/data/processed/submit.csv")
